# The Saltwire Crew – Character Sign-Up

A fictional "join the crew" form for stories, tabletop games, and roleplay. The crew and the city of Marrowgate are invented and not based on any real people or groups.

## Use it
Open `index.html` in a browser. Nothing is sent or stored.

## Publish on GitHub Pages
1. Create a new repo and upload `index.html` and `README.md`.
2. Go to Settings → Pages, choose the `main` branch, and save.
3. Your form will be live at `https://<your-username>.github.io/<repo-name>/`.
